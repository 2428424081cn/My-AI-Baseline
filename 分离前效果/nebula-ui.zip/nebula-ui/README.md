# Nebula UI v1.0.0

零依赖、原生 HTML / CSS / JS 打造的消费工业级组件库：25+ 通用组件、88 个线性 SVG 图标，
设计令牌驱动（亮 / 暗双主题），声明式 `data-*` 属性驱动交互，仅暴露一个全局 `window.UI`。

## 目录结构

```
nebula-ui/
├── assets/
│   ├── nebula-ui.css   # 设计令牌（亮/暗）+ 全部组件样式，零依赖
│   ├── nebula-ui.js    # 声明式委托 + window.UI API + CustomEvent 通信
│   └── icons.svg       # 88 个图标雪碧图（symbol 集合，页面内联使用）
├── docs.html           # 组件文档：每个组件的实时示例 + 可复制代码片段
└── index.html          # 实战演示：控制台 Dashboard，覆盖全部组件
```

## 三步接入

```html
<!-- 1. 引入样式与脚本（无任何外部依赖，无需打包） -->
<link rel="stylesheet" href="assets/nebula-ui.css">
<script src="assets/nebula-ui.js"></script>

<!-- 2. 内联图标雪碧图：把 assets/icons.svg 的 <symbol> 内容复制到页面中
         （<svg style="display:none" aria-hidden="true"> … </svg>） -->

<!-- 3. 写 class 与 data-* 属性即完成，无需任何初始化调用 -->
<button class="ui-btn ui-btn--primary" data-modal-open="#my-modal">开始使用</button>
```

> 为什么内联雪碧图：`file://` 直接打开页面时，跨文件 `<use href="icons.svg#i-x">` 会被
> 浏览器安全策略拦截；内联后本地双击打开也能正常显示图标，且零网络请求。

## 设计原则

- **低耦合**：组件样式互相独立，行为由 `data-*` 声明驱动，HTML 即文档；
- **统一入口**：脚本仅暴露 `window.UI` 一个全局，无命名空间污染；
- **事件通信**：组件行为通过标准 `CustomEvent`（`ui:modal:open`、`ui:toast`、
  `ui:tab:change`、`ui:theme`、`ui:page:change` 等）广播，业务方按需监听；
- **无障碍**：焦点圈定、Esc 关闭、键盘导航、`prefers-reduced-motion` 全部支持。

## 常用 API 速查

```js
UI.toast.success('部署完成');                      // 轻提示
UI.toast({ type: 'info', title: '通知', message: '内容', duration: 4000 });
UI.modal.open('#my-modal'); UI.modal.close('#my-modal');
UI.drawer.open('#my-drawer'); UI.drawer.close('#my-drawer');
UI.tabs.select(document.querySelector('.ui-tabs'), 'activity');
UI.ring.set(ringEl, 76);                          // 环形进度 0-100
UI.theme.toggle(); UI.theme.set('dark'); UI.theme.get();
UI.copy(text, function (ok) { /* … */ });
UI.utils.icon('star');                            // 返回 svg 元素
```

更多属性与事件清单见 `docs.html`（第 18–20 节）。
