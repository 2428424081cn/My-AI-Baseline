/* 小岛咖啡实战：业务状态只存在于此文件，组件层不包含订单逻辑。 */
(function () {
  'use strict';

  const drinks = { '燕麦拿铁': 28, '桂花美式': 24, '海盐Dirty': 32, '柚子冷萃': 30 };
  let orders = [
    { id: 'XD-1028', customer: '周女士', drink: '燕麦拿铁', quantity: 1, total: 28, pickup: '09:10', status: 'done', channel: '小程序' },
    { id: 'XD-1029', customer: '吴先生', drink: '桂花美式', quantity: 2, total: 48, pickup: '09:25', status: 'done', channel: '门店' },
    { id: 'XD-1030', customer: '小满', drink: '海盐Dirty', quantity: 1, total: 32, pickup: '10:05', status: 'done', channel: '门店' },
    { id: 'XD-1031', customer: '陈女士', drink: '柚子冷萃', quantity: 1, total: 30, pickup: '10:40', status: 'pending', channel: '小程序' },
    { id: 'XD-1032', customer: '阿哲', drink: '燕麦拿铁', quantity: 2, total: 56, pickup: '11:15', status: 'pending', channel: '电话预订' },
    { id: 'XD-1033', customer: '许女士', drink: '桂花美式', quantity: 1, total: 24, pickup: '13:20', status: 'pending', channel: '门店' },
    { id: 'XD-1034', customer: '郑先生', drink: '海盐Dirty', quantity: 2, total: 64, pickup: '14:00', status: 'pending', channel: '小程序' },
    { id: 'XD-1035', customer: '栗子', drink: '柚子冷萃', quantity: 1, total: 30, pickup: '14:25', status: 'pending', channel: '门店' }
  ];
  const chartData = {
    current: [32, 41, 38, 46, 52, 68, 61],
    last: [28, 35, 40, 39, 47, 59, 55]
  };
  const state = { filter: 'all', query: '' };
  let weeklyCups = 186;

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  }

  function filteredOrders() {
    const query = state.query.trim().toLowerCase();
    return orders.filter(order => {
      const statusMatches = state.filter === 'all' || order.status === state.filter;
      const text = `${order.id} ${order.customer} ${order.drink} ${order.channel}`.toLowerCase();
      return statusMatches && (!query || text.includes(query));
    });
  }

  function renderStats() {
    const pending = orders.filter(order => order.status === 'pending').length;
    const revenue = orders.reduce((sum, order) => sum + order.total, 0);
    const average = orders.length ? revenue / orders.length : 0;
    document.getElementById('stat-orders').textContent = orders.length;
    document.getElementById('stat-pending').textContent = pending;
    document.getElementById('stat-revenue').textContent = `¥${revenue}`;
    document.getElementById('stat-average').textContent = `客单价 ¥${average.toFixed(1)}`;
    const goalPercent = Math.min(100, Math.round(weeklyCups / 260 * 100));
    document.getElementById('stat-goal').textContent = `${goalPercent}%`;
    LineKit.setProgress('#weekly-goal', goalPercent);
    document.getElementById('goal-foot').textContent = goalPercent === 100 ? '本周目标已达成，干得漂亮。' : `已完成 ${weeklyCups} / 260 杯，还差 ${260 - weeklyCups} 杯。`;
  }

  function renderOrders() {
    const visible = filteredOrders();
    const body = document.getElementById('order-table-body');
    const empty = document.getElementById('order-empty');
    const table = document.querySelector('.order-table');
    document.getElementById('order-count').textContent = `${visible.length} 条记录`;
    empty.hidden = visible.length > 0;
    table.hidden = visible.length === 0;
    body.innerHTML = visible.map(order => `
      <tr>
        <td><span class="order-table-name">${escapeHTML(order.customer)}</span><span class="order-table-meta">${order.id} · ${escapeHTML(order.channel)}</span></td>
        <td><span class="order-table-name">${escapeHTML(order.drink)} × ${order.quantity}</span><span class="order-table-meta">¥${order.total}</span></td>
        <td class="optional-column">${order.pickup}</td>
        <td><span class="lk-badge ${order.status === 'done' ? 'lk-badge--soft' : 'lk-badge--accent'} lk-badge--dot">${order.status === 'done' ? '已完成' : '待出杯'}</span></td>
        <td>${order.status === 'pending' ? `<button class="lk-btn lk-btn--sm" type="button" data-complete="${order.id}">完成<i data-lk-icon="check"></i></button>` : '<button class="lk-btn lk-btn--sm lk-btn--ghost" type="button" disabled>已出杯</button>'}</td>
      </tr>`).join('');
    LineIcons.mount(body);
    renderStats();
  }

  function renderChart(period) {
    const values = chartData[period];
    const max = Math.max(...values);
    const days = ['一', '二', '三', '四', '五', '六', '日'];
    document.getElementById('sales-chart').innerHTML = values.map((value, index) => `
      <div class="chart-column" role="img" aria-label="周${days[index]} ${value} 杯">
        <span class="chart-value">${value}</span>
        <div class="chart-track"><div class="chart-bar" style="--bar-value:${value / max}"></div></div>
        <span class="chart-label">周${days[index]}</span>
      </div>`).join('');
  }

  function setFieldValidity(id, valid) {
    const input = document.getElementById(id);
    const field = document.getElementById(`${id}-field`);
    const error = document.getElementById(`${id}-error`);
    field.classList.toggle('has-error', !valid);
    error.hidden = valid;
    input.setAttribute('aria-invalid', String(!valid));
    if (valid) input.removeAttribute('aria-describedby');
    else input.setAttribute('aria-describedby', error.id);
  }

  function updatePricePreview() {
    const drink = document.getElementById('drink').value;
    const quantity = Number(document.getElementById('quantity').value) || 0;
    const total = drinks[drink] * quantity;
    document.getElementById('order-price-preview').textContent = `合计 ¥${Number.isFinite(total) ? total : 0} · 提交后进入「待出杯」`;
  }

  function ready() {
    renderOrders();
    renderChart('current');

    document.getElementById('order-search').addEventListener('input', event => {
      state.query = event.target.value;
      renderOrders();
    });

    document.querySelector('.order-tabs').addEventListener('lk:tab-change', event => {
      state.filter = event.detail.tab.dataset.orderFilter;
      renderOrders();
    });

    document.getElementById('orders').addEventListener('click', event => {
      const complete = event.target.closest('[data-complete]');
      if (complete) {
        const order = orders.find(item => item.id === complete.dataset.complete);
        if (!order || order.status === 'done') return;
        order.status = 'done';
        renderOrders();
        LineKit.toast({ title: `${order.id} 已出杯`, message: `${order.customer} · ${order.drink} × ${order.quantity}`, icon: 'check-circle' });
        return;
      }
      if (event.target.closest('#clear-order-filter')) {
        state.filter = 'all';
        state.query = '';
        document.getElementById('order-search').value = '';
        LineKit.activateTab(document.getElementById('orders-all-tab'));
        renderOrders();
        document.getElementById('order-search').focus();
      }
    });

    document.getElementById('notification-btn').addEventListener('click', () => {
      LineKit.toast({ title: '备货提醒：燕麦奶', message: '预计还够 18 杯，建议今日补货', icon: 'alert', duration: 4200 });
    });

    document.getElementById('chart-week').addEventListener('change', event => {
      renderChart(event.target.value);
      LineKit.toast({ title: event.target.value === 'current' ? '已切换到本周' : '已切换到上周', icon: 'chart' });
    });

    document.getElementById('export-orders').addEventListener('click', () => {
      const header = ['订单号','顾客','饮品','数量','金额','取餐时间','状态','来源'];
      const rows = orders.map(order => [order.id, order.customer, order.drink, order.quantity, order.total, order.pickup, order.status === 'done' ? '已完成' : '待出杯', order.channel]);
      const csv = [header, ...rows].map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\r\n');
      const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = '小岛咖啡订单.csv';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      LineKit.toast({ title: '订单 CSV 已导出', message: `共 ${orders.length} 条记录`, icon: 'download' });
    });

    const form = document.getElementById('order-form');
    const customer = document.getElementById('customer');
    const quantity = document.getElementById('quantity');
    const pickup = document.getElementById('pickup');
    [customer, quantity, pickup].forEach(input => input.addEventListener('input', () => {
      const valid = input === customer ? Boolean(input.value.trim()) : input === quantity ? input.validity.valid : Boolean(input.value);
      setFieldValidity(input.id, valid);
    }));
    document.getElementById('drink').addEventListener('change', updatePricePreview);
    quantity.addEventListener('input', updatePricePreview);

    form.addEventListener('submit', event => {
      event.preventDefault();
      const customerValid = Boolean(customer.value.trim());
      const quantityValid = quantity.validity.valid;
      const pickupValid = Boolean(pickup.value);
      setFieldValidity('customer', customerValid);
      setFieldValidity('quantity', quantityValid);
      setFieldValidity('pickup', pickupValid);
      if (!customerValid || !quantityValid || !pickupValid) {
        (!customerValid ? customer : !quantityValid ? quantity : pickup).focus();
        LineKit.toast({ title: '订单还差一点信息', message: '请检查标记出的字段', type: 'error' });
        return;
      }
      const nextNumber = Math.max(...orders.map(order => Number(order.id.split('-')[1]))) + 1;
      const drink = document.getElementById('drink').value;
      const count = Number(quantity.value);
      const order = {
        id: `XD-${nextNumber}`,
        customer: customer.value.trim(),
        drink,
        quantity: count,
        total: drinks[drink] * count,
        pickup: pickup.value,
        status: 'pending',
        channel: document.getElementById('channel').value
      };
      orders.push(order);
      weeklyCups += count;
      state.filter = 'all';
      state.query = '';
      document.getElementById('order-search').value = '';
      LineKit.activateTab(document.getElementById('orders-all-tab'));
      renderOrders();
      LineKit.closeDialog(document.getElementById('order-dialog'));
      LineKit.toast({ title: `${order.id} 已加入`, message: `${order.customer} · ${order.drink} × ${order.quantity} · ¥${order.total}`, icon: 'coffee' });
      form.reset();
      quantity.value = 1;
      pickup.value = '14:30';
      updatePricePreview();
    });

    document.querySelectorAll('.demo-nav a').forEach(link => link.addEventListener('click', () => {
      document.querySelectorAll('.demo-nav a').forEach(item => item.classList.toggle('is-active', item === link));
    }));
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready);
  else ready();
})();
