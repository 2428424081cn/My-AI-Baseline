/* 展示页行为：只消费 LineKit / LineIcons 的公开接口。 */
(function () {
  'use strict';

  function ready() {
    const iconGrid = document.getElementById('icon-grid');
    const search = document.getElementById('icon-search');
    const filters = document.getElementById('icon-filters');
    const sizeInput = document.getElementById('icon-size');
    const strokeInput = document.getElementById('icon-stroke');
    const state = { query: '', group: '全部', size: 32, stroke: 1.8 };
    const allNames = Object.keys(LineIcons.paths);

    document.getElementById('hero-icon-count').textContent = allNames.length;
    filters.innerHTML = ['全部', ...Object.keys(LineIcons.groups)].map((group, index) =>
      `<button class="filter-chip" type="button" aria-pressed="${index === 0}" data-group="${group}">${group}</button>`
    ).join('');

    function matchingIcons() {
      const query = state.query.trim().toLowerCase();
      return allNames.filter(name => {
        const inGroup = state.group === '全部' || LineIcons.categoryOf[name] === state.group;
        const haystack = `${name} ${LineIcons.categoryOf[name]}`.toLowerCase();
        return inGroup && (!query || haystack.includes(query));
      });
    }

    function renderIcons() {
      const names = matchingIcons();
      document.getElementById('icon-result-count').textContent = `显示 ${names.length} / ${allNames.length} 枚 · ${state.group}`;
      iconGrid.style.setProperty('--preview-size', `${state.size}px`);
      if (!names.length) {
        iconGrid.innerHTML = `<div class="lk-empty icon-empty"><svg class="lk-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><circle cx="10.7" cy="10.5" r="6.8"/><path d="m15.8 15.9 4.4 4.2"/></svg><h3 class="lk-empty-title">没找到这笔线</h3><p class="lk-empty-text">换一个关键词，或清空当前筛选。</p><button class="lk-btn lk-btn--sm" type="button" data-clear-icons>清空筛选</button></div>`;
        return;
      }
      iconGrid.innerHTML = names.map(name => `
        <button class="icon-card" type="button" data-icon-name="${name}" aria-label="复制 ${name} 图标 SVG">
          ${LineIcons.svg(name, { stroke: state.stroke })}
          <span class="icon-card-name">${name}</span>
          <span class="icon-card-copy" aria-hidden="true">${LineIcons.svg('copy')}</span>
        </button>`).join('');
    }

    filters.addEventListener('click', event => {
      const button = event.target.closest('[data-group]');
      if (!button) return;
      state.group = button.dataset.group;
      filters.querySelectorAll('button').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
      renderIcons();
    });
    search.addEventListener('input', () => { state.query = search.value; renderIcons(); });
    sizeInput.addEventListener('input', () => {
      state.size = Number(sizeInput.value);
      document.getElementById('icon-size-output').textContent = `${state.size}px`;
      iconGrid.style.setProperty('--preview-size', `${state.size}px`);
    });
    strokeInput.addEventListener('input', () => {
      state.stroke = Number(strokeInput.value);
      document.getElementById('icon-stroke-output').textContent = `${state.stroke.toFixed(1)}px`;
      renderIcons();
    });
    iconGrid.addEventListener('click', event => {
      const clear = event.target.closest('[data-clear-icons]');
      if (clear) {
        state.query = '';
        state.group = '全部';
        search.value = '';
        filters.querySelectorAll('button').forEach(item => item.setAttribute('aria-pressed', String(item.dataset.group === '全部')));
        renderIcons();
        search.focus();
        return;
      }
      const card = event.target.closest('[data-icon-name]');
      if (!card) return;
      const name = card.dataset.iconName;
      LineKit.copy(LineIcons.svg(name, { size: state.size, stroke: state.stroke }))
        .then(() => LineKit.toast({ title: `${name}.svg 已复制`, message: `${state.size}px · ${state.stroke.toFixed(1)}px 描边`, icon: 'copy' }))
        .catch(error => LineKit.toast({ title: '复制失败', message: error.message, type: 'error' }));
    });
    renderIcons();

    document.addEventListener('click', event => {
      const trigger = event.target.closest('[data-demo-toast]');
      if (trigger) LineKit.toast({ title: trigger.dataset.demoToast, message: '组件事件已正常触发', icon: 'check-circle' });
      const progress = event.target.closest('[data-progress]');
      if (progress) {
        LineKit.setProgress('#sample-progress', Number(progress.dataset.progress));
        if (progress.dataset.progress === '100') LineKit.toast({ title: '组件整理完成', message: '进度状态已更新为 100%' });
      }
    });

    document.getElementById('show-toast').addEventListener('click', () => {
      LineKit.toast({ title: '草稿保存成功', message: '这是一条由公开 API 创建的消息', icon: 'check' });
    });

    const heroSwitch = document.getElementById('hero-switch');
    heroSwitch.addEventListener('change', () => {
      document.getElementById('hero-switch-caption').textContent = heroSwitch.checked ? 'OPEN / 正在营业' : 'CLOSED / 暂停营业';
    });

    const form = document.getElementById('subscribe-form');
    const nameInput = document.getElementById('subscribe-name');
    const emailInput = document.getElementById('subscribe-email');
    function setValidity(input, valid) {
      const field = document.getElementById(`${input.id}-field`);
      const error = document.getElementById(`${input.id}-error`);
      field.classList.toggle('has-error', !valid);
      error.hidden = valid;
      input.setAttribute('aria-invalid', String(!valid));
      if (!valid) input.setAttribute('aria-describedby', error.id);
      else input.removeAttribute('aria-describedby');
    }
    [nameInput, emailInput].forEach(input => input.addEventListener('input', () => setValidity(input, input === nameInput ? Boolean(input.value.trim()) : input.validity.valid)));
    form.addEventListener('submit', event => {
      event.preventDefault();
      const nameValid = Boolean(nameInput.value.trim());
      const emailValid = emailInput.validity.valid;
      setValidity(nameInput, nameValid);
      setValidity(emailInput, emailValid);
      if (!nameValid || !emailValid) {
        (nameValid ? emailInput : nameInput).focus();
        LineKit.toast({ title: '还有信息需要补全', message: '请检查标记出的字段', type: 'error' });
        return;
      }
      LineKit.toast({ title: `${nameInput.value.trim()}，订阅演示成功`, message: '此页面不会发送或保存个人信息', icon: 'send' });
      form.reset();
    });

    const dot = document.getElementById('timeline-dot');
    const navLinks = Array.from(document.querySelectorAll('.timeline-nav a[href^="#"]'));
    const sections = navLinks.map(link => document.querySelector(link.getAttribute('href'))).filter(Boolean);
    let ticking = false;
    function updateTimeline() {
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      const ratio = maxScroll > 0 ? Math.min(1, Math.max(0, window.scrollY / maxScroll)) : 0;
      const track = dot.parentElement;
      dot.style.setProperty('--timeline-y', `${ratio * Math.max(0, track.clientHeight - 11)}px`);
      let current = sections[0];
      sections.forEach(section => { if (section.getBoundingClientRect().top <= window.innerHeight * .36) current = section; });
      navLinks.forEach(link => link.classList.toggle('is-active', link.getAttribute('href') === `#${current.id}`));
      ticking = false;
    }
    window.addEventListener('scroll', () => {
      if (!ticking) { ticking = true; requestAnimationFrame(updateTimeline); }
    }, { passive: true });
    window.addEventListener('resize', updateTimeline);
    updateTimeline();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready);
  else ready();
})();
