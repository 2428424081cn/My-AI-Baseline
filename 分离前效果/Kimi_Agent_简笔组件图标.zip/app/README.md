# 线物 LineKit 使用文档

线物是一套原生 HTML / CSS / JavaScript 简笔画组件库，包含 55 枚常用 SVG 图标、通用组件样式、声明式交互和完整的咖啡运营台实战。无第三方依赖，无构建步骤。

## 1. 运行与目录

直接打开 `index.html` 即可浏览组件，打开 `demo.html` 查看实战。也可以在项目目录启动任意静态服务器。

```text
app/
├── index.html                 # 图标浏览器、组件展示、快速文档
├── demo.html                  # 小岛咖啡运营台实战
├── README.md                  # 本文档
└── assets/
    ├── css/
    │   ├── linekit.css         # 核心组件：业务项目需要
    │   └── site.css            # 展示站与实战页布局：按需参考
    └── js/
        ├── icons.js            # 独立图标模块
        ├── linekit.js          # 独立通用交互模块
        ├── app.js              # 展示页业务
        └── demo.js             # 实战页业务
```

业务页面最少只需 `linekit.css`。需要图标时加入 `icons.js`；需要弹窗、Toast、标签页等通用行为时加入 `linekit.js`。

## 2. 快速接入

```html
<link rel="stylesheet" href="assets/css/linekit.css">
<script src="assets/js/icons.js" defer></script>
<script src="assets/js/linekit.js" defer></script>

<button class="lk-btn lk-btn--accent" type="button">
  保存草稿 <i data-lk-icon="check"></i>
</button>
```

脚本使用 `defer`，顺序保持 icons.js 在前、linekit.js 在后。若只使用 CSS，不加载脚本也不影响按钮、输入框、卡片、表格等静态外观。

## 3. 设计变量与换肤

CSS 变量分为三层：

1. 基础色板：`--lk-p-sage-*`、`--lk-p-paper`、`--lk-p-ink`、`--lk-p-crimson`。
2. 语义颜色：`--lk-bg`、`--lk-surface`、`--lk-text`、`--lk-accent`。
3. 组件变量：`--lk-btn-bg`、`--lk-icon-size`、`--lk-icon-stroke` 等。

通常在页面自己的样式表中覆盖语义变量，不改组件源码：

```css
:root {
  --lk-accent: oklch(0.62 0.18 35);
  --lk-radius: 12px 9px 13px 10px;
  --lk-icon-stroke: 1.6;
}
```

深色模式：

```html
<html lang="zh-CN" data-lk-theme="dark">
```

也可以放置主题按钮，由核心脚本处理切换：

```html
<button class="lk-btn lk-btn--icon" type="button" data-lk-theme-toggle
        aria-label="切换深色模式"></button>
```

主题偏好使用当前浏览器的 localStorage，不会跨设备同步。禁用本地存储时，切换仍在当前页面有效。

## 4. SVG 图标

### 4.1 声明式调用

```html
<i data-lk-icon="search"></i>
<i data-lk-icon="user" aria-label="个人账户"></i>
```

页面加载后，占位元素自动替换成内联 SVG。无 `aria-label` 时图标按装饰内容处理，使用 `aria-hidden="true"`；按钮若只有图标，应在按钮上提供 `aria-label`。

### 4.2 编程式调用

```javascript
// 返回字符串，适合插入模板
const html = LineIcons.svg('heart', {
  size: 32,
  stroke: 1.6,
  className: 'my-icon',
  label: '收藏'
});

// 返回 SVG DOM 节点
const node = LineIcons.create('check', { size: 20 });
container.appendChild(node);

// 处理动态插入的占位图标
LineIcons.mount(container);
```

### 4.3 图标清单

- 基础操作：search、plus、minus、close、check、arrow-right、arrow-left、arrow-up-right、chevron-down、chevron-right、menu、more。
- 界面导航：home、grid、layers、user、users、settings、bell、calendar、clock、folder、file、image。
- 编辑与状态：download、upload、copy、edit、trash、heart、star、bookmark、link、eye、eye-off、lock、filter、refresh、play、pause。
- 反馈与业务：check-circle、info、alert、help、send、shopping-bag、chart、sun、moon、code、external、location、mail、coffee、leaf。

新增图标时，在 `paths` 中加入统一 `viewBox="0 0 24 24"` 的路径，再把名称加入 `groups`。推荐使用 `fill="none"`、圆角线帽和 1.8 左右描边，保持视觉一致。

## 5. 通用组件速查

| 组件 | 核心类名 / 属性 | 说明 |
|---|---|---|
| 按钮 | `.lk-btn` | 修饰类：`--primary`、`--accent`、`--soft`、`--ghost`、`--danger`、`--icon`、`--sm`、`--lg` |
| 输入框 | `.lk-field`、`.lk-input` | 搭配 `.lk-label`、`.lk-hint`、`.lk-error`；错误状态加 `.has-error` |
| 图标输入框 | `.lk-input-wrap` | 图标和 `.lk-input` 作为直接子元素 |
| 下拉选择 | `.lk-select` | 原生 select，保留键盘能力 |
| 多选 / 单选 | `.lk-choice` | input 后紧跟 `.lk-choice-mark`；单选加 `.lk-choice--radio` |
| 开关 | `.lk-switch` | input 后紧跟 `.lk-switch-track > .lk-switch-thumb` |
| 卡片 | `.lk-card` | 可选 `--flat`、`--interactive` |
| 标记 | `.lk-badge` | 可选 `--accent`、`--soft`、`--dot` |
| 头像 | `.lk-avatar` | 大尺寸使用 `.lk-avatar--lg` |
| 提示 | `.lk-alert` | 关闭按钮加 `data-lk-dismiss` |
| 标签页 | `data-lk-tabs` | 使用 role=tab / tablist / tabpanel，支持方向键 |
| 折叠面板 | `.lk-accordion` | 原生 details / summary，无需 JS |
| 下拉菜单 | `data-lk-dropdown` | 触发器和菜单分别加对应 data 属性 |
| 弹窗 | `.lk-dialog`、`data-lk-open` | 原生 dialog，支持 Escape、背景和按钮关闭 |
| Toast | `LineKit.toast()` | 支持成功、错误、自定义图标和关闭 |
| 进度 | `.lk-progress` | 推荐通过 `LineKit.setProgress()` 更新 |
| 表格 | `.lk-table-wrap > .lk-table` | 小屏在容器内横向滚动，不撑破页面 |
| 空状态 | `.lk-empty` | 搭配图标、标题、解释和下一步操作 |
| 代码块 | `.lk-code` | 复制按钮使用 `data-lk-copy-target` |
| 提示气泡 | `.lk-tooltip`、`data-lk-tooltip` | 悬停与键盘聚焦都能显示 |

## 6. 交互组件写法

### 6.1 标签页

```html
<div data-lk-tabs>
  <div class="lk-tabs" role="tablist" aria-label="内容分类">
    <button class="lk-tab" id="one-tab" role="tab"
            aria-selected="true" aria-controls="one-panel">第一项</button>
    <button class="lk-tab" id="two-tab" role="tab"
            aria-selected="false" aria-controls="two-panel" tabindex="-1">第二项</button>
  </div>
  <div id="one-panel" role="tabpanel" aria-labelledby="one-tab">内容一</div>
  <div id="two-panel" role="tabpanel" aria-labelledby="two-tab" hidden>内容二</div>
</div>
```

点击或使用左右方向键、Home、End 均可切换。每个 `aria-controls` 必须指向现有面板；多个筛选标签也可共享一个动态面板。

### 6.2 下拉菜单

```html
<div class="lk-dropdown" data-lk-dropdown>
  <button class="lk-btn" type="button" data-lk-dropdown-toggle
          aria-expanded="false" aria-haspopup="menu">更多</button>
  <div class="lk-dropdown-menu" data-lk-dropdown-menu role="menu" hidden>
    <button class="lk-menu-item" type="button" role="menuitem">编辑</button>
    <button class="lk-menu-item" type="button" role="menuitem">复制</button>
  </div>
</div>
```

触发器支持点击和 ArrowDown。菜单内使用上下方向键移动，Escape 关闭并归还焦点。业务动作直接监听这些按钮的 click。

### 6.3 弹窗

```html
<button type="button" data-lk-open="confirm-dialog">打开</button>

<dialog class="lk-dialog" id="confirm-dialog" aria-labelledby="confirm-title">
  <h2 id="confirm-title">确认操作</h2>
  <p>这里放置具体内容。</p>
  <button type="button" data-lk-close>取消</button>
</dialog>
```

```javascript
LineKit.openDialog('confirm-dialog');
LineKit.closeDialog(document.getElementById('confirm-dialog'));
```

弹窗使用浏览器原生焦点约束。触发按钮、关闭按钮、Escape 和背景点击都可完成常规关闭流程。

### 6.4 Toast 与复制

```javascript
LineKit.toast({
  title: '保存成功',
  message: '修改已保留在当前页面',
  type: 'success',       // success / error
  icon: 'check-circle',
  duration: 3200
});

LineKit.copy('需要复制的文本')
  .then(() => LineKit.toast({ title: '复制成功' }))
  .catch(error => LineKit.toast({ title: '复制失败', message: error.message, type: 'error' }));
```

纯声明式复制：

```html
<button type="button" data-lk-copy="LineKit">复制名称</button>
<button type="button" data-lk-copy-target="#code-content">复制代码</button>
<pre id="code-content">const ready = true;</pre>
```

### 6.5 进度

```html
<div class="lk-progress">
  <div class="lk-progress-meta">
    <span>上传进度</span><strong data-lk-progress-value>0%</strong>
  </div>
  <div class="lk-progress-track">
    <div class="lk-progress-bar" id="upload-progress"
         role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"></div>
  </div>
</div>
<script>LineKit.setProgress('#upload-progress', 72);</script>
```

## 7. 自定义事件与业务解耦

组件层不读取订单、用户等业务数据。业务脚本只需监听公开事件：

```javascript
document.addEventListener('lk:tab-change', event => {
  console.log(event.detail.panelId);
});

document.addEventListener('lk:dialog-open', event => {
  console.log('弹窗已打开', event.target.id);
});

document.addEventListener('lk:copy', event => {
  console.log('复制内容', event.detail.value);
});
```

动态内容插入后，只调用 `LineIcons.mount(container)` 处理新图标。标签页、弹窗、复制等核心行为采用事件委托，无需重复初始化。

## 8. 实战页说明

`demo.html` 展示以下完整流程：

- 新增订单：校验称呼、数量和取餐时间，计算金额并加入订单表。
- 搜索与筛选：按单号、顾客、饮品、来源搜索，按待出杯 / 已完成筛选。
- 出杯：更新订单状态、待办数量和统计数字。
- CSV 导出：在浏览器生成带 UTF-8 BOM 的订单文件。
- 图表：切换本周 / 上周数据。
- 目标进度：新增订单后同步更新本周杯数目标。
- 主题：切换浅色 / 深色外观。

所有经营数据都是示例，仅存放在页面内存中；刷新后恢复初始数据。页面没有发送网络请求，也没有真实账号、支付或云端数据库。

## 9. 可访问性与适配约定

- 所有主要点击目标至少 44px；移动端不禁止缩放。
- 正文使用显式中文字体栈；中文标题不设置伪斜体。
- 交互组件提供 hover、active、disabled 和清晰的 focus-visible。
- 状态不只依赖颜色，配合文字或图标。
- 系统开启“减少动态效果”时关闭非必要动画和平滑滚动。
- 弹窗、标签页、下拉菜单保留键盘操作。
- 表格滚动限制在自身容器内，页面在 375px 宽度下不应产生横向滚动。

## 10. 扩展建议

新增组件时使用 `.lk-你的组件` 命名，避免修改已有组件的内部选择器。颜色优先引用语义变量，尺寸使用 4 / 8px 间距梯度。若新增交互，优先提供 `data-lk-*` 声明式入口，再补充一个公开 JS 方法；这样展示页、实战页和业务项目可以共享同一份实现。
