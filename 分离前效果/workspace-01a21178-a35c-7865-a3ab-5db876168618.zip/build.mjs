#!/usr/bin/env node
/**
 * Linen M3 Build Script
 * - Generates linen-m3/icons-sprite.svg from linen-m3/icons.js
 * - Bundles src/docs.body.html & src/showcase.body.html with canonical
 *   linen-m3/{tokens.css,components.css,icons.js,linen-m3.js} into standalone
 *   zero-dependency HTML files that preview cleanly offline and in sandboxes.
 */
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const root = process.cwd();

const tokensCss = fs.readFileSync(path.join(root, 'linen-m3/tokens.css'), 'utf8');
const componentsCss = fs.readFileSync(path.join(root, 'linen-m3/components.css'), 'utf8');
const iconsJs = fs.readFileSync(path.join(root, 'linen-m3/icons.js'), 'utf8');
const runtimeJs = fs.readFileSync(path.join(root, 'linen-m3/linen-m3.js'), 'utf8');

// 1. Generate SVG Sprite Sheet
const iconsMod = require('./linen-m3/icons.js');
const spriteSvg = iconsMod.generateSprite();
fs.writeFileSync(path.join(root, 'linen-m3/icons-sprite.svg'), spriteSvg, 'utf8');
console.log(`Generated linen-m3/icons-sprite.svg (${iconsMod.list().length} icons)`);

// 2. Helper to assemble standalone HTML from body template
function buildPage(templateRelPath, outputRelPath) {
  const tplPath = path.join(root, templateRelPath);
  if (!fs.existsSync(tplPath)) {
    console.log(`Skip ${templateRelPath} (not created yet)`);
    return;
  }
  let html = fs.readFileSync(tplPath, 'utf8');
  html = html
    .replace('/*__LM3_TOKENS_CSS__*/', () => tokensCss)
    .replace('/*__LM3_COMPONENTS_CSS__*/', () => componentsCss)
    .replace('/*__LM3_ICONS_JS__*/', () => iconsJs)
    .replace('/*__LM3_RUNTIME_JS__*/', () => runtimeJs);

  fs.writeFileSync(path.join(root, outputRelPath), html, 'utf8');
  const kb = (Buffer.byteLength(html, 'utf8') / 1024).toFixed(1);
  console.log(`Built ${outputRelPath} (${kb} KB)`);
}

buildPage('src/docs.body.html', 'docs.html');
buildPage('src/showcase.body.html', 'showcase.html');
