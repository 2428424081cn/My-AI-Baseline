# Linen M3 — Claude 温润编辑美学 × Google Material Design 3 原生组件与 SVG 图标库

**Linen M3** 是一套零依赖、低耦合的纯原生 HTML / CSS / Vanilla JS 设计系统，融合了 **Anthropic Claude** 的温暖宣纸色阶、赤陶强调色与衬线编辑排版，以及 **Google Material Design 3 (MD3)** 的色阶表面体系、状态层交互反馈、径向涟漪与物理动效曲线。

---

## 目录结构

```text
├── linen-m3/                   # 可直接拷贝进任何项目的独立低耦合核心包
│   ├── tokens.css              # 设计令牌（浅色宣纸 / 暖炭深色 / 4 套 Material You 动态主色）
│   ├── components.css          # 24 套通用组件样式（严格 .lm3-* 命名空间，零全局污染）
│   ├── icons.js                # 61 枚 24×24 手绘 SVG 图标注册表 + 自动水合 + 编程渲染 API
│   ├── icons-sprite.svg        # 零 JS 静态 SVG Sprite 精灵表（<svg><use href="..."/>）
│   └── linen-m3.js             # 事件委托驱动的轻量 JS 运行时（动态 DOM 免重新绑定）
├── docs.html                   # 独立交互式组件库与 61 枚图标实时查阅文档（含一键复制代码）
├── showcase.html               # 实战展示应用「Atelier AI 灵感创作台」（三大完整业务视图）
├── src/                        # docs.html 与 showcase.html 的模板源码
└── build.mjs                   # 单一数据源构建脚本（同步生成 sprite 与独立预览 HTML）
```

---

## 三步零耦合接入

将 `linen-m3/` 目录放入你的项目中，按需引入即可：

```html
<!-- 1. 设计令牌（颜色、排版、圆角、投影、MD3 缓动曲线） -->
<link rel="stylesheet" href="linen-m3/tokens.css" />

<!-- 2. 通用组件样式（按章节独立封装，也可只拷单个组件 CSS） -->
<link rel="stylesheet" href="linen-m3/components.css" />

<!-- 3. SVG 图标系统与事件委托运行时（无需框架、无需打包器） -->
<script src="linen-m3/icons.js"></script>
<script src="linen-m3/linen-m3.js"></script>
```

---

## 为什么这套组件库耦合度极低？

1. **命名空间彻底隔离**：全部类名以 `.lm3-` 开头、CSS 变量以 `--lm3-` 开头，不写任何全局 `button / input / a` 重置规则，放入任何已有项目都不会产生样式冲突。
2. **令牌层与组件层解耦**：`components.css` 内无硬编码色值，只需在 `:root` 或局部容器覆写 `--lm3-primary`、`data-theme="dark"` 或 `data-accent="sage|indigo|amber"` 即可瞬间换肤。
3. **全局单点事件委托**：涟漪（Ripple）、选项卡（Tabs）、弹窗（Dialog）、侧滑抽屉（Side Sheet）、下拉菜单（Menu）、手风琴（Accordion）、筛选标签（Chips）、分段按钮（Segmented）、复制按钮（Copy）均采用 `document` 级委托监听，异步通过 `innerHTML` 或前端框架渲染出的新节点**无需手动重新绑定**。
4. **原生 `CustomEvent` 事件通信**：业务层通过监听 `lm3:tab-change`、`lm3:menu-select`、`lm3:segmented-change`、`lm3:chip-change`、`lm3:theme-change` 等标准事件与组件解耦交互。

---

## 内置 24 套通用组件清单

| 类别 | 组件 |
| :--- | :--- |
| **操作按钮** | MD3 按钮（Filled / Tonal / Elevated / Outlined / Text / Danger + 加载态）、图标按钮（含 Toggle 状态）、FAB 与扩展 FAB |
| **选择与输入** | 分段按钮（单/多选）、智能标签 Chips（Filter / Input 可移除 / Assist）、MD3 Outlined & Filled 浮动标签输入框、Claude 灵感 Prompt Composer、MD3 开关（内置对勾形变）、SVG 描边复选框、单选框、表现力滑块（带浮动气泡） |
| **容器与导航** | MD3 卡片（Elevated / Filled / Outlined / Editorial）、编辑洞察 Callout、滑动指示条 Tabs & Pill Tabs、MD3 Navigation Rail 弹性胶囊、结构化列表、Frosted Top App Bar |
| **浮层与反馈** | MD3 28px 弹窗 Dialog、右侧滑出 Side Sheet、下拉菜单 Menu、纯 CSS Tooltip、反色 Snackbar / Toast（支持撤销回调）、线性与环形进度条、暖纸流光骨架屏、CSS Grid 丝滑手风琴、代码块、头像组、徽标与快捷键帽 |

---

## SVG 图标调用方式（共 61 枚）

1. **声明式自动注入**：
   ```html
   <span data-lm3-icon="claude-burst" data-size="22" data-stroke="1.75"></span>
   ```
2. **静态 SVG Sprite（零 JS）**：
   ```html
   <svg class="lm3-icon" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75">
     <use href="linen-m3/icons-sprite.svg#lm3-icon-sparkle"></use>
   </svg>
   ```
3. **编程渲染 & 动态注册新图标**：
   ```js
   const html = LinenM3.icons.render('sparkle', { size: 20, strokeWidth: 1.75 });
   LinenM3.icons.register('brand-mark', {
     label: '品牌图标',
     body: '<circle cx="12" cy="12" r="8"/>'
   });
   ```

---

## 常用 JS API 速查

```js
// 轻提示（支持 success / info / warning / error 与撤销回调）
LinenM3.toast({
  message: '文稿已归档',
  variant: 'info',
  actionLabel: '撤销',
  onAction: () => LinenM3.toast({ message: '已恢复文稿', variant: 'success' })
});

// 弹窗与侧滑抽屉
LinenM3.dialog.open('#myDialog');
LinenM3.dialog.close('#myDialog');
LinenM3.sheet.open('#mySheet');

// 浅色宣纸 / 暖炭深色 与 Material You 4 套动态色板
LinenM3.theme.setMode('dark');       // 'light' | 'dark' | 'toggle'
LinenM3.theme.setAccent('sage');     // 'terracotta' | 'sage' | 'indigo' | 'amber'

// 动态插入大批含图标/滑块/选项卡的 DOM 后局部刷新
LinenM3.init(containerElement);
```
